//TASK 0:
//Объявите переменную, в которой будете хранить значение скорости в километрах в час, а затем переведите это значение в мили в секунду. Выведете в консоль сообщение: "'x' km per hour  it is 'y' miles per second", заменив x и y вашими значениями.

var speed: Double = 60
var speedMiles = 0.621371

speedMiles = Double(speed) * speedMiles
speedMiles = speedMiles / 60.0 / 60.0

print("\(speed) km per hour it is \(speedMiles) miles per second")
