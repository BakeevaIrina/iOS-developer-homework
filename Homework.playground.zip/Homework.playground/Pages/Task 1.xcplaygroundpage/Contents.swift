//TASK 1:
//Напишите код, который будет вычислять сколько денег находится в копилке. Определим, что возможны монеты номиналом 1 доллар, 50, 25, 10, 5 и 1 цент и мы знаем сколько монет каждого номинала у нас есть. Выведете в консоль сообщение: "There are 10.33$ in the piggy bank". Разумеется, сумма должна соответствовать вашим данным.

let oneDollar = 4
let fiftyDollars = 3
let twentyFiveDollars = 7
let tenDollars = 100
let fiveDollars = 7
let oneCent = 207

var sum = oneDollar * 1 + fiftyDollars * 50 + twentyFiveDollars * 25
                + tenDollars * 10 + fiveDollars * 5
var sumResult = Double(sum) + Double(oneCent) * 0.01
print("There are \(sumResult)$ in the piggy bank")
