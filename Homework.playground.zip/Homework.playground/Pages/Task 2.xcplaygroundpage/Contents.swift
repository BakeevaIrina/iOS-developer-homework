//Напишите код, который выведет в консоль ответ на вопрос делиться ли одно целое число на другое без остатка, а если нет, то найдите остаток от деления. Разрешено использовать только операторы деления и сравнения. Результат выведите в консоль в виде: "'x' is divisible by 'y' without remainder" или "'x' is not divisible by 'y' without remainder. Remains: 'z'".

let firstNumber = 6
let secondNumber = 4

let result = firstNumber % secondNumber
    if result == 0 {
        print("\(firstNumber) is divisible by \(secondNumber) without remainder")
    } else {
        print("\(firstNumber) is not divisible by \(secondNumber) without remainder. Remains: \(result)")
    }

